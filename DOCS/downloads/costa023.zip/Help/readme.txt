Costa - A GUI for MS-DOS
Version 0.2.3
By Jacob Christensen
*******************************************
ReadMe and last-minute information
*******************************************

Costa, copyright 2004 Jacob Christensen, all rights reserved.

Costa is NOT an operating system, and therefore some programs, which would normally be found in an
operating system, aren't included. This includes text editors, paint programs etc.

I cannot be held responsible for any damage caused to your system by Costa (Costa won't hurt your
computer, i just have to write that line due to legal stuff. I don't get it, i just do it...)
Costa is freeware and may freely be distrubted, as long as the code behind it remains the same.
You are allowed to change the script files, though (known by the extension .csf). See scripts.txt
for further information.

Also, I would like to thank you for downloading Costa. I really appreciate it.

Please also notice that Costa can't run if placed in the root directory of the
drive (C:\ for example), but has to be in a subfolder (C:\costa for example),
because Costa automatically puts a backslash (\) after paths.


Check http://www.jacobpalm.dk for updates.