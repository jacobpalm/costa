Before running Costa 0.9.0 PREVIEW, please write the path
to Costa in a text editor and save it as C:\CDEPATH.INI

Remember to include a trailing backslash.

Examples:

  C:\Costa\
  C:\GUIS\Costa\
  C:\Projects\Costa\

