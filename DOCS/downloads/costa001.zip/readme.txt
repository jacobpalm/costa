Costa - A GUI for MS-DOS
Version 0.0.1
************************

This is a very early beta-release of Costa. There's not many things to do.

Check http://www.freewebs.com/web_hvalrossen/costa.htm for updates.